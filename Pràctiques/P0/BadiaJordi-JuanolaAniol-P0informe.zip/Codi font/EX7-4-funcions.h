
/* Declaracions de les funcions  */

int ObteInfo(char *nom, int longnom, char *dni, int *edatanys);
int TrobaEdatEnMesos(int anys, int *mesos);
int MostraResultat(const char *nom, const char *dni, int edatanys, int edatmesos);
